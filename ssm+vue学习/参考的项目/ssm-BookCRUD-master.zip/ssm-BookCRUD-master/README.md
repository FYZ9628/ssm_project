# ssm-BookCRUD
运用ssm框架，图书增删改查案例
书籍展示页面
![image](https://raw.githubusercontent.com/GAOli-cong/ssm-BookCRUD/master/img/img1.png)
添加页面
![image](https://raw.githubusercontent.com/GAOli-cong/ssm-BookCRUD/master/img/img2.png)
查询
![image](https://raw.githubusercontent.com/GAOli-cong/ssm-BookCRUD/master/img/img3.png)
删除
![image](https://raw.githubusercontent.com/GAOli-cong/ssm-BookCRUD/master/img/img4.png)
